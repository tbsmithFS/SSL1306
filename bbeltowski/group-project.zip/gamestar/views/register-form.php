<!-- register-FORM.PHP START -->    
    
    
    <section class="row-fluid">
    	<div class="span7">
        	<h5>Register Page!</h5>
        </div>
        <div class="span5">
        	<form action="/user/perform_register" enctype="multipart/form-data"
             method="post">
			
			<div class="login-form">
            <div class="control-group">
              <input name="name" type="text" class="login-field" value="" placeholder="Enter your name" id="login-name" />
              <label class="login-field-icon fui-user" for="login-name"></label>
            </div>
            
            <div class="control-group">
              <input name="email" type="email" class="login-field" value="" placeholder="Your E-Mail" id="login-email" />
              <label class="login-field-icon fui-mail" for="login-email"></label>
            </div>

            <div class="control-group">
              <input name="password" type="password" class="login-field" value="" placeholder="Password" id="login-pass" />
              <label class="login-field-icon fui-lock" for="login-pass"></label>
            </div>
            
            <!--
<div class="control-group">
              <input type="password" class="login-field" value="" placeholder="Re-Enter Password" id="login-repass" />
              <label class="login-field-icon fui-lock" for="login-repass"></label>
            </div>
-->

            <!-- <a class="btn btn-primary btn-large btn-block" href="#">Register</a> -->
            <input class="btn btn-primary btn-large btn-block" type="submit" value="Register">
			</form>
            <p><a class="login-link" href="/home/login">Already a Member?</a><a class="login-link" href="#">Lost your password?</a></p>
          </div>
        </div>
    </section>
    
</div> <!-- / ENDS HEADER.PHP container tag -->
<!-- register-FORM.PHP END -->  