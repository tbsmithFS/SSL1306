<!-- SIDEBAR.PHP -->  
<section class="row-fluid">
    	<aside class="span3">
    	    <h6> Current Controller <?php echo $data['controller'] ?> </h6>
        	<p> Here is a left for Categories.</p>
        	<p> <a href="/home/home">GO HOME</a></p>
        	<p> <a href="/home/aboutUs">ABOUT US</a></p>
        	<p> <a href="/user/form">FORM</a></p>
        	<p> <a href="/user/data">DATABASE</a></p>
        </aside>

<!-- SIDEBAR.PHP -->  
