<!-- GAME.PHP -->
<li class="span4">
<div class="thumbnail">
  <?php	
		echo('<img src="/images/games/'. $data['gameId'] .'.jpg">');
  ?>
  <div class="caption">
    <?php	
		echo("<h3>" . $data['name'] . "</h3>");
	?>
    <div class="progress">
    <?php	
		echo('<div class="bar" style="width:'. $data['total'] .'%"></div>');
	?>
	</div>
    
    <?php	
		echo('<p>'. $data['description'] .'</p>');
	?>
    <!-- <a class="btn btn-primary btn-large btn-block" href="http://designmodo.com/flat">Vote Now</a> -->
    <a class="btn btn-info btn-large btn-block" href="/user/single_game/">Get Info</a>
  </div>
</div>
</li>      
<!-- GAME.PHP -->  