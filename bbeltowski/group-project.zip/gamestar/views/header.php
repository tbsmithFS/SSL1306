<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>GameStar</title>
	
	<!-- Loading Bootstrap -->
	<link href="/bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css"/>
	<!-- <link href="bootstrap/css/bootstrap-responsive.css" rel="stylesheet" type="text/css"/> -->
	
	<!-- Loading Flat UI -->
	<link href="/css/flat-ui.css" rel="stylesheet"/>
	
	<!-- Loading FavIcon -->
	<link rel="shortcut icon" href="images/favicon.ico"/>

	<!-- HTML5 shim for IE backwards compatibility -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>

<body>
    <div class="container">
    
      <div class="span12">
          <div class="navbar navbar-inverse">
            <div class="navbar-inner">
              <div class="container">
                <button type="button" class="btn btn-navbar" data-toggle="collapse" data-target="#nav-collapse-01"></button>
                <div class="nav-collapse collapse" id="nav-collapse-01">
                  <ul class="nav">
                    <li class="active">
                      <a href="/">
                        Main Menu
                        <!-- <span class="navbar-unread">1</span> -->
                      </a>
                    </li>
                    <li>
                      <a href="/user/home">
                        Games
                        <!-- <span class="navbar-unread">1</span> -->
                      </a>
                      <ul>
                        <li>
                          <a href="#fakelink">Platforms</a>
                          <ul>
                            <li><a href="#fakelink">Xbox One</a></li>
                            <li><a href="#fakelink">Playstation 4</a></li>
                            <li><a href="#fakelink">PC</a></li>
                          </ul> <!-- /Sub menu -->
                        </li>
                        <li>
                          <a href="#fakelink">Genres</a>
                          <ul>
                            <li><a href="#fakelink">Action</a></li>
                            <li><a href="#fakelink">Sim</a></li>
                            <li><a href="#fakelink">Sports</a></li>
                          </ul> <!-- /Sub menu -->
                        </li>
                        <li><a href="#fakelink">Popular</a></li>
                      </ul> <!-- /Sub menu -->
                    </li>
                    <li>
                      <a href="#fakelink">
                        About Us
                      </a>
                    </li>
                    <li>
                      <a href="/home/login">
                        Log-In
                      </a>
                    </li>
                  </ul>
                </div><!--/.nav -->
              </div>
            </div>
          </div>
      </div><!-- ENDS WHOLE NAV -->