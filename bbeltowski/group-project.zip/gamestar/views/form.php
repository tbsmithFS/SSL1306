<!-- FORM.PHP START -->    
    
    
    <section class="row-fluid">
    	<div class="span9 offset3">
        	<h5>Register Page!</h5>
			
			<?php
			
			include 'views/helpers/form_builder.php';
			
			$form = new FormBuilder($validation_data, $form_data);
			$form->formHeader('/user/perform_register');
			$form->textInput('name');
			$form->textInput('email');
			$form->textInput('password', true);
			$form->submit();
			$form->formCloser();
			
			?>

        </div>
    </section>
    
    </section><!-- ends 2/3 section -->
<!-- FORM.PHP END -->  