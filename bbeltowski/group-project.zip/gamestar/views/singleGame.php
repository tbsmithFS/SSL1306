<!-- SingleGame.PHP -->    
	<div class="row-fluid">
        <div class="row demo-tiles">
        <ul class="thumbnails tile">
          <li class="span4">
            <div class="thumbnail">
              <img data-src="bootstrap/js/holder.js/300x200" alt="300x200" style="width: 300px; height: 200px;" src="/images/games/35.jpg">
              <div class="caption">
                <h3>Gears of War 4</h3>
                <!--<div class="progress">
		          <div class="bar" style="width: 60%;"></div>
		          <div class="bar bar-warning" style="width: 5%;"></div>
		          <div class="bar bar-danger" style="width: 12%;"></div>
		          <div class="bar bar-success" style="width: 10%;"></div>
		          <div class="bar bar-info" style="width: 13%;"></div>
		        </div>-->
		        <div class="progress">
				  <div class="bar" style="width: 52%"></div>
				</div>
		        
                <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
                <a class="btn btn-primary btn-large btn-block" href="http://designmodo.com/flat">Vote Now</a>
                <a class="btn btn-large btn-block" href="http://designmodo.com/flat">Get Info</a>
              </div>
            </div>
          </li>
          <li class="span4">
            <div class="thumbnail">
              <img data-src="holder.js/300x200" alt="300x200" style="width: 300px; height: 200px;" src="images/games/41.jpg">
              <div class="caption">
                <h3>Killzone 2</h3>
                <div class="progress">
				  <div class="bar" style="width: 80%"></div>
				</div>
                <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
                <a class="btn btn-primary btn-large btn-block" href="http://designmodo.com/flat">Vote Now</a>
                <a class="btn btn-large btn-block" href="http://designmodo.com/flat">Get Info</a>
              </div>
            </div>
          </li>
          <li class="span4">
            <div class="thumbnail">
              <img data-src="holder.js/300x200" alt="300x200" style="width: 300px; height: 200px;" src="images/games/42.jpg">
              <div class="caption">
                <h3>Killzone 2</h3>
                <!--<div class="progress">
		          <div class="bar" style="width: 20%;"></div>
		          <div class="bar bar-warning" style="width: 10%;"></div>
		          <div class="bar bar-danger" style="width: 30%;"></div>
		          <div class="bar bar-success" style="width: 10%;"></div>
		          <div class="bar bar-info" style="width: 20%;"></div>
		        </div>-->
		        <div class="progress">
				  <div class="bar" style="width: 52%"></div>
				</div>
                <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
                <a class="btn btn-primary btn-large btn-block" href="http://designmodo.com/flat">Vote Now</a>
                <a class="btn btn-large btn-block" href="http://designmodo.com/flat">Get Info</a>
              </div>
            </div>
          </li>
        </ul>
        </div> <!-- ENDS tiles -->
      </div><!-- ENDS Thumbnails -->
      
      <div class="row-fluid">
        <div class="row demo-tiles">
        <ul class="thumbnails tile">
          <li class="span4">
            <div class="thumbnail">
              <img data-src="holder.js/300x200" alt="300x200" style="width: 300px; height: 200px;" src="images/games/35.jpg">
              <div class="caption">
                <h3>Gears of War</h3>
                <!--<div class="progress">
		          <div class="bar" style="width: 60%;"></div>
		          <div class="bar bar-warning" style="width: 5%;"></div>
		          <div class="bar bar-danger" style="width: 12%;"></div>
		          <div class="bar bar-success" style="width: 10%;"></div>
		          <div class="bar bar-info" style="width: 13%;"></div>
		        </div>-->
		        <div class="progress">
				  <div class="bar" style="width: 52%"></div>
				</div>
		        
                <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
                <a class="btn btn-primary btn-large btn-block" href="http://designmodo.com/flat">Vote Now</a>
                <a class="btn btn-large btn-block" href="http://designmodo.com/flat">Get Info</a>
              </div>
            </div>
          </li>
          <li class="span4">
            <div class="thumbnail">
              <img data-src="holder.js/300x200" alt="300x200" style="width: 300px; height: 200px;" src="images/games/41.jpg">
              <div class="caption">
                <h3>Killzone 2</h3>
                <div class="progress">
				  <div class="bar" style="width: 80%"></div>
				</div>
                <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
                <a class="btn btn-primary btn-large btn-block" href="http://designmodo.com/flat">Vote Now</a>
                <a class="btn btn-large btn-block" href="http://designmodo.com/flat">Get Info</a>
              </div>
            </div>
          </li>
          <li class="span4">
            <div class="thumbnail">
              <img data-src="holder.js/300x200" alt="300x200" style="width: 300px; height: 200px;" src="images/games/42.jpg">
              <div class="caption">
                <h3>Killzone 2</h3>
		        <div class="progress">
				  <div class="bar" style="width: 52%"></div>
				</div>
                <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
                <a class="btn btn-primary btn-large btn-block" href="http://designmodo.com/flat">Vote Now</a>
                  <div class="tile-highlight">
	                <h6>Over All Score</h6>
	                <div class="progress">
					  <div class="bar" style="width: 80%"></div>
					</div>
	                <h6>Game Play</h6>
	                <div class="progress progress-info">
					  <div class="bar bar-info" style="width: 20%"></div>
					</div>
					<h6>Graphics</h6>
					<div class="progress progress-success">
					  <div class="bar bar-success" style="width: 40%"></div>
					</div>
					<h6>Game Stats</h6>
					<div class="progress progress-warning">
					  <div class="bar bar-warning" style="width: 60%"></div>
					</div>
					<h6>Game Stats</h6>
					<div class="progress progress-danger">
					  <div class="bar bar-danger" style="width: 80%"></div>
					</div>
                  </div>
                <a class="btn btn-large btn-block" href="http://designmodo.com/flat">Get Info</a>
              </div>
            </div>
          </li>
        </ul>
        </div> <!-- ENDS tiles -->
      </div><!-- ENDS Thumbnails -->
      

    </div> <!-- / ENDS HEADER.PHP container tag -->
<!-- SingleGame.PHP -->  