<!-- HOME.PHP -->
	<section class="row-fluid">
           	<h3> LOADING SINGLE GAME FROM mySQL</h3>			
			<?php
			
				echo("Starts CONNECTION... <br/><br/>");

				$host = '127.0.0.1';
		        $user = 'root';
		        $pass = 'root';
		        $port = '8889';
		        $dbname = 'GameStar';

		        $dbh = new PDO("mysql:host=$host;port=$port;dbname=$dbname", $user, $pass);
		        
		        //$gameId = $_GET[];
		        
		        $stmnt = $dbh->query("select * from game where gameId = 2");
		        //:gameId
				$result = $stmnt->fetchAll(PDO::FETCH_ASSOC);
				
				var_dump($result);

		        
		       
			 ?>
    </section>
    
    <div class="row-fluid demo-tiles">
      <div class="span4">
      
        <!--
<div class="thumbnail">
          <img data-src="holder.js/300x200" alt="300x200" style="width: 300px; height: 200px;" src="images/games/41.jpg">
        </div>
        <br/>
-->
        
          <div class="tile">
		    <h6>Over All Score</h6>
		    <div class="progress">
			  <div class="bar" style="width: 80%"></div>
			</div>
		    <h6>Game Play</h6>
		    <div class="progress progress-info">
			  <div class="bar bar-info" style="width: 20%"></div>
			</div>
			<h6>Graphics</h6>
			<div class="progress progress-success">
			  <div class="bar bar-success" style="width: 40%"></div>
			</div>
			<h6>Game Stats</h6>
			<div class="progress progress-warning">
			  <div class="bar bar-warning" style="width: 60%"></div>
			</div>
			<h6>Game Stats</h6>
			<div class="progress progress-danger">
			  <div class="bar bar-danger" style="width: 80%"></div>
			</div>
          </div>
          
      </div><!-- ENDS Side Info Bar -->
      <div class="span8">
        <div class="thumbnail">
          <img data-src="holder.js/300x200" alt="300x200" style="width: 300px; height: 200px;" src="images/games/41.jpg">
        </div>
        <h1>Game Title</h1>
        <div class="palette-silver">
        <h6><strong>CONSOLE:</strong> Xbox <strong>Genre:</strong> Action</h6>
        </div>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce est quam, mollis id lorem a, volutpat fermentum mauris. Phasellus sagittis, erat quis feugiat sagittis, quam turpis accumsan lorem, eu placerat nisi mi ut mauris. Cras vitae quam eget diam rhoncus tempor. Integer quis ligula auctor, laoreet dolor quis, interdum sem. Nunc risus turpis, semper sit amet leo ac, vulputate sodales elit. Mauris fermentum suscipit risus tempor eleifend.</p>
      </div>
              
      </div><!-- ENDS Row -->
      
      <div class="row-fluid demo-tiles">
        <div class="tile span4">
        	<form action="#" enctype="multipart/form-data"
             method="post">
			
			<div class="login-form">
            
            <h3 class="rating-title">Gameplay</h3>
            <select name="herolist" value="0" class="select-block">
	            <option value="0" selected="selected">0</option>
	            <option value="10">1</option>
	            <option value="20">2</option>
	            <option value="30">3</option>
	            <option value="40">4</option>
	            <option value="50">5</option>
	            <option value="60">6</option>
	            <option value="70">7</option>
	            <option value="80">8</option>
	            <option value="90">9</option>
	            <option value="100">10</option>
            </select>
            
            <h3 class="rating-title">Garphics</h3>
            <select name="herolist" value="0" class="select-block">
	            <option value="0" selected="selected">0</option>
	            <option value="10">1</option>
	            <option value="20">2</option>
	            <option value="30">3</option>
	            <option value="40">4</option>
	            <option value="50">5</option>
	            <option value="60">6</option>
	            <option value="70">7</option>
	            <option value="80">8</option>
	            <option value="90">9</option>
	            <option value="100">10</option>
            </select>
            
            <h3 class="rating-title">Storyline</h3>
            <select name="herolist" value="0" class="select-block">
	            <option value="0" selected="selected">0</option>
	            <option value="10">1</option>
	            <option value="20">2</option>
	            <option value="30">3</option>
	            <option value="40">4</option>
	            <option value="50">5</option>
	            <option value="60">6</option>
	            <option value="70">7</option>
	            <option value="80">8</option>
	            <option value="90">9</option>
	            <option value="100">10</option>
            </select>
            
            <h3 class="rating-title">Awesomeness</h3>
            <select name="herolist" value="0" class="select-block">
	            <option value="0" selected="selected">0</option>
	            <option value="10">1</option>
	            <option value="20">2</option>
	            <option value="30">3</option>
	            <option value="40">4</option>
	            <option value="50">5</option>
	            <option value="60">6</option>
	            <option value="70">7</option>
	            <option value="80">8</option>
	            <option value="90">9</option>
	            <option value="100">10</option>
            </select>

            <input class="btn btn-danger btn-large btn-block" type="submit" value="Submit Your Vote">
			</form>
        </div>
      	
      </div>
      
      <div class="span8">
      		<p>other people's votes</p>
      		
      </div>
           

    </div> <!-- / ENDS HEADER.PHP container tag -->
<!-- HOME.PHP -->  