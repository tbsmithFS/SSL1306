    <p>You have been logged in.</p>
    <p>You may now view the <a href="/home/secret">secret page</a></p>
    <h1> Logged in now</h1>
