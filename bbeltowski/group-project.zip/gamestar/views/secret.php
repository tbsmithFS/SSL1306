<?php include "models/protector.php"; ?>

Aliens shot JFK!
