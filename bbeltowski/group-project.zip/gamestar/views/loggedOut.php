    <p>You have been logged out.</p>
    <p><a href="/home/login">Login</a> or <a href="/home/register">Register</a></p>
