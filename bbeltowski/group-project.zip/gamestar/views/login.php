<!-- LOGIN.PHP START -->    
    <section class="row-fluid">
    	<div class="span7">
        	<h5>Login!</h5>
        	<i class="icon-search"></i>
        </div>
        <div class="span5">
        	<form action="/user/login" enctype="multipart/form-data"
             method="post">
			
			<div class="login-form">
            <div class="control-group">
              <input name="name" type="text" class="login-field" value="" placeholder="Enter your name" id="login-name" />
              <label class="login-field-icon fui-user" for="login-name"></label>
            </div>
            
            <!--
<div class="control-group">
              <input name="email" type="email" class="login-field" value="" placeholder="Your E-Mail" id="login-email" />
              <label class="login-field-icon fui-mail" for="login-email"></label>
            </div>
-->

            <div class="control-group">
              <input name="password" type="password" class="login-field" value="" placeholder="Password" id="login-pass" />
              <label class="login-field-icon fui-lock" for="login-pass"></label>
            </div>

            <input class="btn btn-primary btn-large btn-block" type="submit" value="Login">
			</form>
			<a class="login-link" href="#">Lost your password?</a></p>
          </div>
        </div>
    </section>
    
</div> <!-- / ENDS HEADER.PHP container tag -->
<!-- LOGIN.PHP END -->