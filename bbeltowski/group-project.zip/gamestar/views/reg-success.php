<!-- FORM.PHP START -->    
    </section><!-- ends 2/3 section -->
    
    <section class="row-fluid">
    	<div class="span9 offset3">
    		<p>SUCCESS</p>
        	<?php echo $data['user'] ?>	
        </div>
    </section>
<!-- FORM.PHP END -->  