<!-- HOME.PHP -->
		<section class="row-fluid">
		       	<h3> DATABASE FROM mySQL</h3>
		       	<ul>			
				<?php
				
					echo("Starts CONNECTION... <br/><br/>");
		
					$host = '127.0.0.1';
			        $user = 'root';
			        $pass = 'root';
			        $port = '8889';
			        $dbname = 'GameStar';
		
			        $dbh = new PDO("mysql:host=$host;port=$port;dbname=$dbname", $user, $pass);
			        
			        /*$stmnt = $dbh->query("select * from game");
				    $result = $stmnt->fetchAll(PDO::FETCH_ASSOC);*/
				    
				    require_once "models/view.php";
				    $v = new View();
				    
				    foreach($dbh->query('SELECT * FROM game') as $game) {
				        $v->getView("game_view", $game);
				    }
					
				?>
		       	</ul>
		</section>
           

    </div> <!-- / ENDS HEADER.PHP container tag -->
<!-- HOME.PHP -->  