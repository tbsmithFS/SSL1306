<?php
if (empty($_GET['controller'])) {
    $con = 'user';
}else {
    $con = $_GET['controller'];
}

if ($con == 'home'){
    include "controllers/home.php";
    $controller = new Home();
    $controller->dispatch($_GET);
} else if ($con == 'user') {
    include "controllers/user.php";
    $user = new User();
    $user->dispatch($_GET);
}
/* echo ('Game Star');	 */
?>
