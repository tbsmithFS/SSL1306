<?php


include_once "models/dbconnector.php";
include_once "models/salt.php";
require_once "models/view.php";
include_once "models/user.php";

class User {
    function dispatch($query=''){
        
		$v = new View();
		//$v->printHeader();
	
		$data = array(
    		'username' => "Brad",
    		'controller' => "user");
	
		$v->getView("header", $data);
		/* $v->getView('sidebar', $data); */
		
		if(empty($query['action'])) {
            $action = 'register';
        } else {
            $action = $query['action']; 
        }
        
        if ($action == 'register') {
            $this->show_register_form();
        } else if ($action == 'perform_register') {
            $validation_data = $this->perform_register($_POST);
            if ($validation_data['successful'] == true) {
            	//echo 'ADDING NEW USER';
            	//echo($validation_data['name']);
            	$usermodel = new User_model();
            	$usermodel->addUser($validation_data['name'], $validation_data['email'], $validation_data['password']);
            	
            	$this->login($validation_data['name'], $validation_data['password']);
            } else {
                $this->show_register_form($_POST, $validation_data);
            }
        } else if ($action == 'data') {
	        $v->getView("data", $data);
        } else if ($action == 'home') {
	        $v->getView("home", $data);
        } else if ($action == 'single_game') {
	        $v->getView("single_game", $data);

        } else if ($action == 'login') {
	        //$v->getView("login", $data);
	        $login_data = $_POST;
	        $this->login($login_data['name'], $login_data['password']);
        } else {
            echo "Didn't recognize the action " . $action;
        }
		//$v->getView('footer', $data);
	}
	
	function show_register_form($form_data=array(), $validation_data=array()) {
        require_once "views/register-form.php";
    }

    function perform_register($form_data) {
        require_once "views/helpers/form_validator.php";
        $form_validator = new FormValidator();
        $validation_data = $form_validator->validate($form_data);
        //echo 'PERFORM REG';
        //var_dump($validation_data);
        
        return $validation_data;
    }

    /*
function show_success_page() {
        require_once "views/reg-success.php";
    }
*/
    
    public function login($username='', $password='') {
        $con = new DBConnector();
        $db = $con->connect();

        // get userId
        $usermodel = new User_model();
        $userId = $usermodel->getUserId($username);

        if (empty($userId)) {
            $data['username']['msg'] = "No such username";
            $v = new View();
            $v->getView("header");
            $v->getView("login", $data);
            $v->getView("footer");
            exit();
        }

        // get user's salt
        $salter = new Salt();
        $salt = $salter->getUserSalt($userId);

        // get hashed password
        $hashedPassword = $usermodel->getUserPassword($usermodel->getUserId($username));

        // create this hash
        $thisHash = md5($password . $salt);

        /*
echo "hashed: $hashedPassword<br/>";
        echo "this: $thisHash<br/>";
*/
		//var_dump($username , $password);
		
        $v = new View();
        if ($hashedPassword == $thisHash) {
            $_SESSION['isLoggedIn'] = True;
            //$v->getView('header');
            //var_dump();
            $v->getView('home', $data);
            
            echo("<!--".'hey!!!!!!!!!!!!!!!!'."-->");
            //exit();
        } else {
            $data['password']['msg'] = "Bad Password";
            //$v->getView('header');
            $v->getView('login', $data);
            
        }
        $v->getView('footer');
        //exit();
        
    }

}
?>