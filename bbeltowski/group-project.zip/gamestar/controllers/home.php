<?php

require_once 'models/view.php';

class Home {
    function dispatch($query=''){
        if(empty($query['action'])) {
            $action = 'home';
        } else {
            $action = $query['action'];
        }

		$v = new View();
		$v->printHeader();
	
		$data = array(
    		'username' => "Brad",
    		'controller' => "home");
	
		$v->getView("header", $data);
		/* $v->getView('sidebar', $data); */
		if ($action == 'home'){
    		$v->getView("home", $data);
		} else if ($action == 'login'){
    		$v->getView('login', $data);
		} else if ($action == 'singleGame'){
    		$v->getView('singleGame', $data);
		} else if ($action == 'loggedOut'){
    		$v->getView('loggedOut', $data);
		} else if ($action == 'secret'){
    		$v->getView('secret', $data);
		} else {
    		$v->getView('home', $data);
		}
		$v->getView('footer', $data);
	}
}
?>
