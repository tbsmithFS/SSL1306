<?php
//echo('Hey');
class DBConnector {
	
    
	public function connect() {
        
$host = '127.0.0.1';
        $user = 'root';
        $pass = 'root';
        $port = '8889';
        $dbname = 'GameStar';

        return new PDO("mysql:host=$host;port=$port;dbname=$dbname", $user, $pass);

		//echo("tt");
		
		/*
$dbh = new PDO('mysql:host=localhost;dbname=test', $user, $pass, array(
		    PDO::ATTR_PERSISTENT => true
		);
*/
		
    }
    
    public function getRandomUser() {
        $stmnt = $this->db->query("select * from user order by rand() limit 1");
        return $stmnt->fetchAll(PDO::FETCH_ASSOC);
    }


}

?>
