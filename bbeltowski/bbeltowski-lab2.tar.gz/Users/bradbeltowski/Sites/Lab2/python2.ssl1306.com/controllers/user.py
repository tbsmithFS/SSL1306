#!/usr/bin/python

from models.view import View

class User():
	def dispatch(self, query={}):
		if 'action' not in query:
			action = 'home'
		else:
			action = query.getvalue('action')
		data ={'username': 'Guest',
			'controller' : 'home'
		}

		v = View()
		v.print_header()
		v.get_view("header", data)

		if action == 'home':
			v.get_view("home", data)
		elif action == 'aboutUs':
			v.get_view("aboutUs", data)
		elif action == 'changePassword':
                        v.get_view("change_password", data)
		else:
			v.get_view("home", data)

		v.get_view("sidebar", data)
		v.get_view("footer", data)
