<!-- FOOTER.PHP -->  
<footer class="span2 offset10">
    	<p> &copy; Copyright 2013</p>
    </footer>
    
</section><!-- ENDS Main Wrapper -->


<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="/js/bootstrap.min.js"></script>
<!-- FOOTER.PHP -->  
</body>
</html>
