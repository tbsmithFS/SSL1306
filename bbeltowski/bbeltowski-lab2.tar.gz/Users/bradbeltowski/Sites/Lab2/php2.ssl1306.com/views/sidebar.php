<!-- SIDEBAR.PHP -->  
<section class="row-fluid">
    	<aside class="span3">
    	    <h6> Current Controller <?php echo $data['controller'] ?> </h6>
        	<p> Here is a left for Categories.</p>
        </aside>
<!-- SIDEBAR.PHP -->  
