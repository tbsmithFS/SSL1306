<?php

require_once 'models/view.php';

class User {
    function dispatch($query=''){
        
		$v = new View();
	
		$data = array(
    		'username' => "GI Brad",
    		'controller' => "user");
    	// Default page loaded in
		$v->getView("header", $data);
		$v->getView('sidebar', $data);
		
		// Checking actions for center page
		if(empty($query['action'])) {
            $action = 'definition';
        } else {
            $action = $query['action'];
        }
        
        // Definition Starting
        if ($action == 'definition') {
            $this->show_definition_form();
        } else if ($action == 'get_translation') {
            $validation_data = $this->get_translation($_POST);
            if (!empty($validation_data)) {
                $this->show_success_page($validation_data);
                
            } else {
                $this->show_definition_form($_POST, $validation_data);
                var_dump($validation_data);
                echo('FAIL WHALE');
            }
        } else if ($action == 'data') {
	        $v->getView("data", $data);
        } else {
            echo "Didn't recognize the action " . $action;
        }
		$v->getView('footer', $data);
	}
	
	function show_definition_form($form_data=array(), $validation_data=array()) {
        require_once "views/definition.php";
    }
    
    function get_translation($form_data) {
		$validation_data = $form_data;
        return $validation_data;
    }

    function show_success_page($data) {
        //require_once "views/reg-success.php";
        $v = new View();
        $v->getView("reg-success", $data);
    }

}
?>