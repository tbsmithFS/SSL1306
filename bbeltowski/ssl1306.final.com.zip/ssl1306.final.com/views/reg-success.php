<!-- FORM.PHP START -->    
    </section><!-- ends 2/3 section -->
    
    <section class="row-fluid">
    	<div class="span9 offset3">
    		<p>SUCCESS</p>
        	<?php var_dump($data) ?>	
        	
        	<!-- http://glosbe.com/gapi/translate?from=eng&dest=fra&format=xml&phrase=cat&pretty=true -->
        </div>
    </section>
<!-- FORM.PHP END -->  