<!-- DATA.PHP START -->    
    
    
    <section class="row-fluid">
    	<div class="span9 offset3">
        	<h3> DATABASE FROM mySQL</h3>			
			<?php
			
				echo("Starts CONNECTION... <br/><br/>");

				include "models/DBConnector.php";
				
				$db = new DBConnector();
				
				$result = $db->getRandomUser();
				
				var_dump($result);
				
				//$db->addUser("joe", "smith", "123 main ave", "Orlando", "FL", "32825", "234-123-4231");
				//$firstname='', $lastname='', $address='', $city='', $state='', $zip='', $phone=''
				
			?>
        </div>
    </section>
    
    </section><!-- ends 2/3 section -->
<!-- DATA.PHP END -->  