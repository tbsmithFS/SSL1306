<!-- HOME.PHP -->    
 <article class="span9">
        	<h2> Blog Title </h2>
        	<p> Here is the first article.</p>
        </article>
    </section><!-- ends 2/3 section -->
    
    <section class="row-fluid">
    	<article class="span9 offset3">
        	<h2>Blog Title</h2>
        	<p> Here is another article.</p>
        </article>
    </section>
    
    <section class="row-fluid">
    	<div class="span9 offset3">
        	<!--<div class="row-fluid">
            	<div class="span6">
                	<h3> Box Infro 1</h3>
                    <img src="img/art1.jpg" />
                    <p>Here is some text about a picture</p>
                </div>
                <div class="span6">
                	<h3> Box Infro 2</h3>
                    <img src="img/art2.jpg" />
                    <p>Here is some text about a picture</p>
                </div>
            </div> -->
        </div>
    </section>
<!-- HOME.PHP -->  