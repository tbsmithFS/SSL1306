<!-- definition.PHP START -->    
    
    
    <section class="row-fluid">
    	<div class="span9 offset3">
        	<h4>Definition Page!</h4>
			The rules are:<br/>
			<ul>
			<li>English word to translate into another language selected below</li>
			<li>Choose a second language to translate into.</li>
			<li>Run the translator to get the word and definition</li>
			</ul>
			
			<form action="/user/get_translation" enctype="multipart/form-data" method="post">
		
	            <div class="control-group">
	              <input name="word" type="text" class="login-field" value="" placeholder="Enter your name" id="login-name" />
	              <label class="login-field-icon fui-user" for="login-name"></label>
	            </div>
	
	            <div class="control-group">
	              <select name="language" value="0" class="select-block">
		            <option value="German" selected="selected">German</option>
		            <option value="100">10</option>
	              </select>
	            </div>
	            
	            <input class="btn btn-primary" type="submit" value="Translate">
	            
			</form>

        </div>
    </section>
    
    </section><!-- ends 2/3 section -->
<!-- definition.PHP END -->  