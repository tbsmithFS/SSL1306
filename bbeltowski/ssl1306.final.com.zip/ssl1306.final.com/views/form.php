<!-- FORM.PHP START -->    
    
    
    <section class="row-fluid">
    	<div class="span9 offset3">
        	Register Page!<br/>
			The rules are:<br/>
			<ul>
			<li>Name must contain letters and spaces only</li>
			<li>Email must be like name@example.com</li>
			<li>VerifyEmail must be same as Email</li>
			<li>Password must be at least eight characters long</li>
			<li>Rating must be chosen</li>
			<li>Fav number must be an integer</li>
			</ul>
			
			<?php
			
			include 'views/helpers/form_builder.php';
			
			$form = new FormBuilder($validation_data, $form_data);
			$form->formHeader('/user/perform_register');
			$form->textInput('name');
			$form->textInput('email');
			$form->textInput('verifyemail');
			$form->textInput('password', true);
			$form->radio('rating', array('1', '2', '3', '4'));
			$form->textInput('favNumber');
			$form->submit();
			$form->formCloser();
			
			?>

        </div>
    </section>
    
    </section><!-- ends 2/3 section -->
<!-- FORM.PHP END -->  