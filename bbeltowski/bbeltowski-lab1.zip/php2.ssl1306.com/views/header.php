<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Brad's First Bootstrap</title>

<!-- CSS Style Sheets -->
<link href="/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="/css/bootstrap-responsive.css" rel="stylesheet" type="text/css"> 

<!-- HTML5 shim for IE backwards compatibility -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>

<body>

<section class="container-fluid">
	<header class="row-fluid">
    	<h1 class="span12"> My First Blog Page!</h1>
    </header>