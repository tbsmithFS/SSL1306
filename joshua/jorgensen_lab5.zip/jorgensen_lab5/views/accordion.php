<div id="main_content">

	<div class="light_bg">
		<div class="wrapper">
			<h2>Accordion</h2>
		</div>
	</div>

	<div class="dark_bg">
		<div class="wrapper">
			<ul id="accordion_shell">

				<!-- Pricing -->
				<li>
					<div class="accordion_content">
						<a class="toggle" href="#content1"><h3>Pricing</h3></a>

						<div id="content1" class="content">
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam nec nulla ligula, nec egestas nibh. Morbi imperdiet nulla a purus molestie ac vulputate lacus varius. Nullam ut nisl quis massa commodo interdum. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Mauris ultrices condimentum sapien semper vestibulum. Aliquam tristique risus id erat ultrices sit amet tristique dui condimentum. Quisque ultrices risus ac magna scelerisque interdum a eu lectus.</p>
						</div>

						<a class="arrow" href="#content1"><img src="/images/arrow_down.png" alt="Arrow" /></a>
					</div>
				</li>

				<!-- Packages -->
				<li>
					<div class="accordion_content">
						<a class="toggle" href="#content2"><h3>Packages</h3></a>

						<div id="content2" class="content">
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam nec nulla ligula, nec egestas nibh. Morbi imperdiet nulla a purus molestie ac vulputate lacus varius. Nullam ut nisl quis massa commodo interdum. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Mauris ultrices condimentum sapien semper vestibulum. Aliquam tristique risus id erat ultrices sit amet tristique dui condimentum. Quisque ultrices risus ac magna scelerisque interdum a eu lectus.</p>
						</div>

						<a class="arrow" href="#content2"><img src="/images/arrow_down.png" alt="Arrow" /></a>
					</div>
				</li>

				<!-- Packages -->
				<li>
					<div class="accordion_content">
						<a class="toggle" href="#content3"><h3>Content Delivery</h3></a>

						<div id="content3" class="content">
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam nec nulla ligula, nec egestas nibh. Morbi imperdiet nulla a purus molestie ac vulputate lacus varius. Nullam ut nisl quis massa commodo interdum. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Mauris ultrices condimentum sapien semper vestibulum. Aliquam tristique risus id erat ultrices sit amet tristique dui condimentum. Quisque ultrices risus ac magna scelerisque interdum a eu lectus.</p>
						</div>

						<a class="arrow" href="#content3"><img src="/images/arrow_down.png" alt="Arrow" /></a>
					</div>
				</li>

				<!-- Deadlines -->
				<li>
					<div class="accordion_content">
						<a class="toggle" href="#content4"><h3>Deadlines</h3></a>

						<div id="content4" class="content">
							<p>Sed lacinia dui iaculis nisi aliquet posuere. Nam condimentum, velit vel feugiat mattis, leo nibh posuere quam, rhoncus scelerisque nisl massa sed nunc. Vivamus ut orci enim, in dignissim lorem. Nulla dictum elit ut velit ultricies volutpat. Etiam at vehicula ipsum. Integer massa nisl, blandit eu porta ac, consectetur non nulla. Quisque dapibus tortor in lorem blandit ac tempus nisl fermentum. Curabitur vel orci nulla. Nulla quis metus odio. Etiam a tellus in ipsum eleifend pharetra. Nulla sit amet nibh velit. Nullam a neque sit amet elit cursus sollicitudin. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Etiam sollicitudin auctor mi eget pharetra. Donec placerat nunc ac orci eleifend venenatis. Nullam risus odio, rhoncus eget aliquet id, elementum vel justo.</p>
						</div>

						<a class="arrow" href="#content4"><img src="/images/arrow_down.png" alt="Arrow" /></a>
					</div>
				</li>

			</ul>
		</div>
	</div>

</div><!-- main_content -->