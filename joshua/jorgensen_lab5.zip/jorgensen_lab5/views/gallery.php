<div id="main_content">

	<div class="light_bg">
		<div class="wrapper">
			<section>
				<h2>Image Gallery</h2>

				<div id="main_image">
					<a id="back" href="#">Back</a>
					<img id="largeImg" src="/images/large/01.jpg" alt="#" />
					<a id="next" href="#">Next</a>
				</div>
			</section>

			<aside>
				<ul id="images">
					<li class="thumbnail"><a href="/images/large/01.jpg" title="#"><img src="/images/thumbs/01.jpg" alt="#" /></a></li>
					<li class="thumbnail"><a href="/images/large/02.jpg" title="#"><img src="/images/thumbs/02.jpg" alt="#" /></a></li>
					<li class="thumbnail"><a href="/images/large/03.jpg" title="#"><img src="/images/thumbs/03.jpg" alt="#" /></a></li>
					<li class="thumbnail"><a href="/images/large/04.jpg" title="#"><img src="/images/thumbs/04.jpg" alt="#" /></a></li>
					<li class="thumbnail"><a href="/images/large/05.jpg" title="#"><img src="/images/thumbs/05.jpg" alt="#" /></a></li>
					<li class="thumbnail"><a href="/images/large/06.jpg" title="#"><img src="/images/thumbs/06.jpg" alt="#" /></a></li>
					<li class="thumbnail"><a href="/images/large/07.jpg" title="#"><img src="/images/thumbs/07.jpg" alt="#" /></a></li>
					<li class="thumbnail"><a href="/images/large/08.jpg" title="#"><img src="/images/thumbs/08.jpg" alt="#" /></a></li>
					<li class="thumbnail"><a href="/images/large/09.jpg" title="#"><img src="/images/thumbs/09.jpg" alt="#" /></a></li>
					<li class="thumbnail"><a href="/images/large/10.jpg" title="#"><img src="/images/thumbs/10.jpg" alt="#" /></a></li>
					<li class="thumbnail"><a href="/images/large/11.jpg" title="#"><img src="/images/thumbs/11.jpg" alt="#" /></a></li>
				</ul>
			</aside>
		</div>
	</div>

	<div class="dark_bg">
		<div class="wrapper">
			<h2>Other Albums</h2>
			<div class="other_albums">
				<img src="/images/other_albums.jpg" alt="Other Album" />
			</div>

			<div class="other_albums">
				<img src="/images/other_albums.jpg" alt="Other Album" />
			</div>

			<div class="other_albums">
				<img src="/images/other_albums.jpg" alt="Other Album" />
			</div>
		</div>
	</div>

</div><!-- main_content -->