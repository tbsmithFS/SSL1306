<div id="main_content">

	<div class="light_bg">
		<div class="wrapper">

			<h2>Login</h2>

			<form 
				class="signInForm"
				action="/user/login"
				enctype="multipart/form-data"
				method="post">

				<label for="loginUsername">Username</label>
				<input id="loginUsername" name="username" type="text" maxlength="50" />
				<?php

				// var_dump($data);
				if (!empty($data['username']) && !empty($data['username']['msg'])) {
					// echo '9 ';
					echo $data['username']['msg'];
					// echo ' 8';
				}
				?>

				<?php
				if (!empty($data['password']) && !empty($data['password']['msg'])) {
					echo $data['password']['msg'];
				}
				?>
				<label for="loginPassword">Password</label>
				<input id="loginPassword" name="password" type="password" maxlength="50" />

				<input class="loginButton" name="submit" type="submit" value="Login" />
			</form>
		</div>
	</div>

	<div class="dark_bg">
		<div class="wrapper">
			<h2>User Benefits</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce vel sapien urna. Aliquam lacus nulla, tincidunt a pellentesque a, dictum quis lorem. Pellentesque euismod diam non tellus dignissim et lacinia sem ornare. Nulla et libero eu lectus aliquam consectetur. Donec tincidunt purus non tortor scelerisque et luctus nibh euismod. Nullam convallis tortor semper magna congue et pharetra urna mollis. Nam iaculis volutpat pulvinar. Sed vehicula mi nec ligula ultrices vel vehicula massa varius. Nunc in velit mi. Vivamus ac mi vel massa laoreet pharetra ac id dolor. Nulla et magna felis. Sed pellentesque mattis purus id aliquet.</p>
		</div>
	</div>
</div>