<div id="main_content">

	<div class="light_bg">
		<div class="wrapper">
			<h2>Auto Complete</h2>
		</div>
	</div>

	<div class="dark_bg">
		<div class="wrapper">

			<div id="ac_search">
				<h3>Recipient:</h3>

				<form id="myForm">
					<input id="search_auto" type="search" name="search" />
				</form>

				<div class="results">
					<ul id="input_result">

					</ul>
				</div>
			</div>
				
		</div>
	</div>

</div><!-- main_content -->