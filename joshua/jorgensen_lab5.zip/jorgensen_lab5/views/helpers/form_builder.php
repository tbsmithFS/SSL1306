<?php

Class FormBuilder {

	private $validation_data;
	private $form_data;

	function __construct($validation_data = array(), $form_data = array()) {
		$this->validation_data = $validation_data;
		$this->form_data = $form_data;
	}

	function formHeader($action) {
		echo '<form action="'.$action.'" '.
             'enctype="multipart/form-data"
             method="post">' . "\n";
	}

	function formCloser() {
		echo "</form>\n";
	}

	function errorRow($name) {
		echo '<span class="name_errors" id="f_last_error">' . $this->validation_data[$name]['error_message'] . "</span>\n";
	}

	function textInput($name, $password=false, $label='') {

		$type = $password ? 'password' : 'text';

		if(!empty($this->form_data[$name])) {
			$current_value = $this->form_data[$name];
		} else {
			$current_value = '';
		}

		echo "<label><span>*</span>" . $label . "</label>\n" . 
			"<input name=\"$name\" type=\"$type\" value=\"" . $current_value . "\"/>\n";

		if(!empty($this->validation_data[$name]) && $this->validation_data[$name]['has_error'] == true) {
			$this->errorRow($name);
		}
	}

	function submit() {
		echo "<input id=\"submit\" name=\"submit\" type=\"submit\" value=\"SEND\" />\n";
	}

}