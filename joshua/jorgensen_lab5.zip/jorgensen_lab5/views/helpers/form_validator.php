<?php

Class FormValidator {

    function validate($query) {

        $data['successful'] = true;

        // email
        if (!preg_match('/^\w+@\w+\.\w+$/', $query['email'])) {
            $data['successful'] = false;
            $data['email']['has_error'] = true;
            $data['email']['error_message'] = "Email address must look like user@example.com.";
        }
        
        // password
        if (strlen($query['password']) < 8) {
            $data['successful'] = false;
            $data['password']['has_error'] = true;
            $data['password']['error_message'] = "The password must be at least 8 characters long.";
        } 

        return $data;

    }   

}

?>
