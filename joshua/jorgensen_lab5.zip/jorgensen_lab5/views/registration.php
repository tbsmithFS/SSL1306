<div id="main_content">

	<div class="light_bg">
		<div class="wrapper">
			<section>
				<h2>User Registration</h2>
				
				<?php 

				include 'views/helpers/form_builder.php';

				$form = new FormBuilder($validation_data, $form_data);
				$form->formHeader('/user/perform_register');
				$form->textInput('email', false, 'Email');
				$form->textInput('username', false, 'Username');
				$form->textInput('password', true, 'Password');
				$form->submit();
				$form->formCloser();
				
				?>

			</section>

			<img src="/images/registration.jpg" alt="Register today" />
		</div>
	</div>

	<div class="dark_bg">
		<div class="wrapper">
			<h2>User Benefits</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce vel sapien urna. Aliquam lacus nulla, tincidunt a pellentesque a, dictum quis lorem. Pellentesque euismod diam non tellus dignissim et lacinia sem ornare. Nulla et libero eu lectus aliquam consectetur. Donec tincidunt purus non tortor scelerisque et luctus nibh euismod. Nullam convallis tortor semper magna congue et pharetra urna mollis. Nam iaculis volutpat pulvinar. Sed vehicula mi nec ligula ultrices vel vehicula massa varius. Nunc in velit mi. Vivamus ac mi vel massa laoreet pharetra ac id dolor. Nulla et magna felis. Sed pellentesque mattis purus id aliquet.</p>
		</div>
	</div>

</div><!-- main_content -->