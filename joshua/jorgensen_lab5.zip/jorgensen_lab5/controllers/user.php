<?php

include_once "models/DBConnector.php";
include_once "models/salt.php";
include_once 'models/view.php';
include_once "models/user.php";

class User {

	var $sessionLength = 5;

	function dispatch($query='') {

		if(empty($query['action'])){
			$action = 'home';
		} else {
			$action = $query['action'];
		}

		$v = new View();
		$v->printHeader();

		$userModel = new User_model();
		// var_dump($userModel);

		$data = array(
			'username' => 'Joe',
			'controller' => 'user'
		);

		if($action == 'home') {	
			$v->getView('user_home', $data);
		}

		else if($action == 'registration') {
			$data['bodyId']='registration'; //applies id to <body> for CSS
			$v->getView('header', $data);
			$v->getView('registration', $data);
		}

		else if ($action == 'perform_register') {
			// print 3;
			$data['bodyId']='registration'; //applies id to <body> for CSS
			// $v->getView('header', $data);

            $validation_data = $this->perform_register($_POST);

            if ($validation_data['successful'] == true) {
                $this->show_loggedIn_page();
            } else {
                $this->show_register_form($_POST, $validation_data);
            }            
        }

		else if ($action == 'login') {
			// echo 'login test';
			$this->login($_POST['username'], $_POST['password']);
		}

		else if ($action == 'logout') {
			$this->logout();
		}

		else {
			$v->getView('user_home', $data);	
		}

		$v->getView('sidebar', $data);
		$v->getView('footer', $data);
	}


	/*
	====== Login ======
	*/

	public function login($username='', $password='') {
		$con = new DBConnector();
		$db = $con->connect();

		// echo 'login works';

		//== get userId
		$usermodel = new User_model();
		$userId = $usermodel->getUserId($username);

		if (empty($userId)) {
            $data['username']['msg'] = "No such username";
            $v = new View();
            $v->getView("header");
            $v->getView("login", $data);
            $v->getView("footer");
            exit();
        }

        // get user's salt
        $salter = new Salt();
        $salt = $salter->getUserSalt($userId);

        // get hashed password
        $hashedPassword = $usermodel->getUserPassword($usermodel->getUserId($username));

        // create this hash
        $thisHash = md5($password . $salt);

        $v = new View();
        if ($hashedPassword == $thisHash) {
            $_SESSION['isLoggedIn'] = True;
            $v->getView('header');
            $v->getView('loggedIn');
            exit();
        } else {
            $data['password']['msg'] = "Bad Password";
            $v->getView('header');
            $v->getView('login', $data);
        }
        $v->getView('footer');
        exit();
	}


	/*
	====== Logout ======
	*/

	public function logout() {
        session_destroy();
        $_SESSION['isLoggedIn'] = False;
        $v = new View();
        $v->getView('header');
        $v->getView('loggedOut');
        $v->getView('footer');
    }

    /*
	====== Show Register Form ======
	*/

	function show_register_form($form_data=array(), $validation_data=array()) {
        require_once "views/registration.php";
    }

    /*
	====== Perform Register ======
	*/

    function perform_register($form_data) {
    	// print 2;
        require_once "views/helpers/form_validator.php";
        $form_validator = new FormValidator();
        $validation_data = $form_validator->validate($form_data);

        $userModel = new User_model();

        // echo 'test';
		$userModel->addUser(
			$_POST['username'],
			$_POST['email'],
			$_POST['password']
		);

		$this->login($_POST['username'], $_POST['password']);
		// var_dump($db);

        return $validation_data;
    }

    /*
	====== Show Logged In Page ======
	*/

    function show_loggedIn_page() {
        require_once "views/loggedIn.php";
    }
}

?>