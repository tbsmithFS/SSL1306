<?php

require_once 'models/view.php';

class Home {
	function dispatch($query=''){
		if(empty($query['action'])){
			$action = 'home';
		}else {
			$action = $query['action'];
		}

		$v = new View();
		$v->printHeader();

		$data = array(
			'username' => array('msg' => ''),
			'controller' => 'home'
		);

		if($action == 'home') {
			$data['bodyId']='home';
			$v->getView('header', $data);
			$v->getView('home', $data);
		} 
		else if($action == 'login') {
			$v->getView('header', $data);
			$v->getView('login', $data);
		}
		else if($action == 'loggedOut') {
			$v->getView('header', $data);
			$v->getView('loggedOut', $data);
		}
		else if($action == 'secret') {
			$v->getView('header', $data);
			$v->getView('secret', $data);
		}
		else if($action == 'accordion') {
			$data['bodyId']='accordion';
			$v->getView('header', $data);
			$v->getView('accordion', $data);
		} 
		else if($action == 'autoComplete') {
			$data['bodyId']='auto_complete';
			$v->getView('header', $data);
			$v->getView('auto_complete', $data);
		} 
		else if($action == 'blog') {
			$data['bodyId']='blog';
			$v->getView('header', $data);
			$v->getView('blog', $data);
		} 
		else if($action == 'gallery') {
			$data['bodyId']='gallery';
			$v->getView('header', $data);
			$v->getView('gallery', $data);
		}
		else {
			$data['bodyId']='home';
			$v->getView('header', $data);
			$v->getView('home', $data);	
		}
		$v->getView('sidebar', $data);
		$v->getView('footer', $data);
	}
}

?>