<?php

include_once "models/DBConnector.php";
include_once "models/salt.php";

class User_model {

    public function addUser($username='', $email='', $password='') {

        // echo "user: $username, email: $email, password: $password<br>";

        $con = new DBConnector();
        $db = $con->connect();
 
        /* ==== 
        insert user
        ==== */
        $stmnt = $db->prepare("insert into users (username, email)
            values (:username, :email)");
        $stmnt->execute(array(
            ':username' => $username,
            ':email' => $email));
        
        /* ==== 
        get userId
        ==== */
        $userId = $db->lastInsertId();
        // echo "user id: $userId <br>";

        /* ==== 
        create salt
        ==== */
        $salter = new Salt();
        $salt = $salter->getRandomString(20);
        // echo "salt: $salt <br>";

        /* ==== 
        insert salt
        ==== */
        $stmnt = $db->prepare(
            "update users set salt = :salt where userId = :userId"
        );

        // echo "updating with userId = $userId, salt = $salt<br>";
        $stmnt->execute(array(
            ':userId' => $userId,
            ':salt' => $salt
        ));

        /* ==== 
        insert hashed password
        ==== */
        $stmnt = $db->prepare("update users set passwordHash = :passwordHash where userId = :userId");

        // echo "inserting with userId $userId, pass = $password, salt = $salt<Br>";

        $stmnt->execute(array(
            ':passwordHash' => md5($password.$salt),
            ':userId' => $userId));

    }

    public function getUserPassword($userId) {
        $con = new DBConnector();
        $db = $con->connect();

        $stmnt = $db->prepare("select passwordHash from users 
            where userId = :userId");
        $stmnt->execute(array(':userId'=>$userId));
        $rows = $stmnt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $row) {
            return $row['passwordHash'];
        }

    }

    public function getUserId($username='') {
        $con = new DBConnector();
        $db = $con->connect();

        $stmnt = $db->prepare("select userId from users where username = :username");
        $stmnt->execute(array(':username'=>$username));
        $rows = $stmnt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $row) {
            return $row['userId'];
        }
    }

}

?>
