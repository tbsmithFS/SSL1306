(function(){ 

	var regform = document.querySelector('#registrationForm');
	// var regform = document.querySelector('#myform');

	var formInputs = regform.querySelectorAll('div input');
	// var formInputs = regform.querySelectorAll('li input');

	//This should not be here, just using it for troubleshooting
	var pattern = /kbcaiy3g4i7g3gd/;
	var pass = pattern.text;
	var name = 'test';
	// // patterns = function(){};

	var patterns = {
		"email": function(elem){
			console.log('works');
			var pattern = /^([0-9a-zA-Z]([-.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$/;
			var pass = pattern.text(elem.value);
			// console.log(pass);
			return pass;
		},
		"phone": function(elem){
			console.log('works');
			var pattern = /^(\([2-9]|[2-9])(\d{2}|\d{2}\))(-|.|\s)?\d{3}(-|.|\s)?\d{4}$/;
			var pass = pattern.text(elem.value);
			return pass;
		}
	};



	ryu(formInputs).each(function() {
		var name = this.getAttribute('id');
		var errorMsg = this.nextSibling.nextSibling;
		// console.log(name);
		
		this.onkeyup = function(e){
			console.log(name);
			// var pass = patterns[name](this);

			if(!pass) {
				errorMsg.style.display = 'block';
				this.style.backgroundColor = 'red';
			}else {
				errorMsg.style.display = 'none';
				this.style.backgroundColor = 'green';
			};

			e.preventDefault();
			return false;
		}
		
	});

/*
	for(var i=0, max=formInputs.length; i<max; i++) {
		formInputs[i].onkeyup = function(e){
			var name = this.getAttribute('name');
			var pass = patterns[name](this);

			var errorMsg = this.nextSibling.nextSibling.nextSibling.nextSibling;
			if(!pass) {
				errorMsg.style.display = 'block';
				this.style.backgroundColor = 'red';
			}else {
				errorMsg.style.display = 'none';
				this.style.backgroundColor = 'green';
			};

			e.preventDefault();
			return false;
		}
	}
*/
	regform.onsubmit = function(e){
		e.preventDefault();
		return false;
	}

})();