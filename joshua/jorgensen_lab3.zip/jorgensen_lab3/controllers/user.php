<?php

require_once 'models/view.php';

class User {
	function dispatch($query=''){
		if(empty($query['action'])){
			$action = 'home';
		}else {
			$action = $query['action'];
		}

		$v = new View();
		$v->printHeader();

		$data = array(
			'username' => 'Joe',
			'controller' => 'user'
		);

		if($action == 'home') {	
			$v->getView('user_home', $data);
		}
		else if($action == 'registration') {
			$data['bodyId']='registration'; //applies id to <body> for CSS
			// var_dump($data['bodyId']);
			// echo ($data);
			$v->getView('header', $data);
			$v->getView('registration', $data);

		}
		else if ($action == 'perform_register') {
			$data['bodyId']='registration'; //applies id to <body> for CSS
			$v->getView('header', $data);

            $validation_data = $this->perform_register($_POST);
            // var_dump($validation_data);
            if ($validation_data['successful'] == true) {
                $this->show_success_page();
            } else {
                $this->show_register_form($_POST, $validation_data);
            }
        }
		else {
			$v->getView('user_home', $data);	
		}
		$v->getView('sidebar', $data);
		$v->getView('footer', $data);
	}

	function show_register_form($form_data=array(), $validation_data=array()) {
        require_once "views/registration.php";
    }

    function perform_register($form_data) {
        require_once "views/helpers/form_validator.php";
        $form_validator = new FormValidator();
        $validation_data = $form_validator->validate($form_data);
        return $validation_data;
    }

    function show_success_page() {
        require_once "views/register_success.php";
    }
}

?>