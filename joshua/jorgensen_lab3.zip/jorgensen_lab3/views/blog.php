<div id="main_content">

	<div class="light_bg">
		<div class="wrapper">
			<h2>Personal Blog</h2>

			<div class="blog_features">
				<div id="search_input">
					<input id="search" type="search" name="search" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Search'"  placeholder="Search" />
					<img id="search_icon" src="/images/search_icon.png" alt="Search for posts" />
				</div>

				<p>&#35; Posts Per Page</p>
				<select name="Number of posts">
					<option value="3">3</option>
					<option value="3">5</option>
					<option value="3">10</option>
					<option value="3">25</option>
				</select>
			</div>
		</div>
	</div>

	<div class="dark_bg">
		<div class="wrapper">
			<div class="blog_post">
				<h3>My First Post</h3>
				<img src="/images/blog_img1.jpg" alt="Blog Post 1" />
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus luctus sagittis facilisis. Duis sollicitudin facilisis massa, quis convallis augue faucibus vitae. Curabitur libero quam, tempus in aliquam ut, dignissim vel velit. Phasellus auctor nisi eget enim vulputate at volutpat nisi vestibulum. Morbi dui velit, vehicula eu facilisis a, rhoncus lobortis ligula. Nullam eu libero nunc. Nunc vel consequat magna. Proin sagittis tortor at mi gravida lacinia. Nunc auctor lorem et eros ullamcorper sit amet rutrum nisi consectetur. Duis facilisis, tortor sit amet ullamcorper adipiscing, lorem ligula facilisis nunc, vel viverra felis turpis non libero.</p>

				<p>Nam eu augue magna, id vulputate lacus. Vestibulum a justo sed diam lacinia fermentum. Duis accumsan, odio sit amet cursus condimentum, mi turpis pellentesque nibh, nec faucibus purus nunc sit amet lorem. Quisque et turpis nec est lacinia volutpat vitae sit amet ligula. In dapibus porttitor odio, lacinia blandit elit hendrerit sed. Fusce condimentum commodo enim at suscipit. Sed sed lacinia justo. Praesent non enim a ligula hendrerit accumsan congue eget odio. Cras sit amet massa sed ipsum lobortis fringilla id eget dui. Cras justo mi, ultrices et gravida non, varius a ante. Etiam vestibulum, enim id vulputate lacinia, elit mauris volutpat elit, at facilisis mi arcu at odio. Donec dignissim justo id lacus scelerisque commodo. Suspendisse convallis nibh sit amet dui placerat pretium. Morbi faucibus facilisis laoreet.</p>

				<p>Ut congue malesuada tincidunt. Suspendisse convallis bibendum urna vitae mollis. Phasellus fermentum elementum est et commodo. Cras varius faucibus urna sed sagittis. Maecenas bibendum euismod nisi a mattis. Duis lectus tortor, convallis sed egestas eu, aliquam nec sem. Fusce mollis justo lacinia arcu rutrum id placerat odio cursus.</p>
			</div>

			<div class="blog_post">
				<h3>My Second Post</h3>
				<img class="right" src="images/blog_img2.jpg" alt="Blog Post 2" />
				<p>Vivamus tempus elementum enim, vel malesuada arcu faucibus quis. Donec aliquam, urna blandit tristique eleifend, risus est imperdiet nulla, quis consectetur erat odio tempor neque. Aliquam vel lorem erat. Suspendisse et dui turpis. Vestibulum feugiat, lacus at hendrerit pretium, eros urna lacinia ligula, eu elementum justo libero ut libero. In tempor condimentum ligula, vitae viverra nulla fermentum nec. Maecenas tempor, mi adipiscing luctus gravida, sem orci accumsan est, quis tincidunt sapien orci eu magna. Fusce luctus vestibulum enim vitae suscipit. Aliquam pulvinar ornare massa, at ornare purus fringilla vel. Praesent feugiat hendrerit ante, gravida rhoncus ante ullamcorper ut. Vestibulum ac eros a sapien venenatis hendrerit. Morbi sed enim non magna ultricies sodales eu eu nisi. Suspendisse tellus dui, pretium vulputate pharetra in, lobortis at massa.</p>

				<p>Nulla nec nibh eu lorem malesuada porttitor non vitae massa. Donec dictum, tellus fermentum ultricies dapibus, turpis elit viverra velit, et hendrerit tellus risus sed risus. Pellentesque eu sapien molestie sem tincidunt fringilla. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec vitae iaculis nisl. In leo dolor, imperdiet sit amet fermentum non, pulvinar ut eros. Etiam auctor, augue non lobortis rutrum, neque lectus congue purus, et tempus nulla mi quis turpis. Praesent convallis mollis dui accumsan vulputate. Vestibulum non lorem at ante pretium commodo. Sed sed nisl ligula. Nullam mollis porta pretium. Duis in mauris ut augue tempor elementum at eget arcu.</p>
			</div>

			<div class="blog_post">
				<h3>My Third Post</h3>
				<img src="/images/blog_img3.jpg" alt="Blog Post 1" />
				<p>Nam quis est arcu, sodales porttitor magna. Nam nec laoreet sapien. Integer non sapien tortor, id malesuada orci. Fusce id diam nisl, a adipiscing velit. Pellentesque sed dui et quam egestas lobortis ut id ligula. Aliquam blandit posuere eros, ac suscipit ante interdum ac. Nullam luctus lorem vitae diam aliquet porttitor. In hac habitasse platea dictumst. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas nec velit vitae sem vestibulum lacinia ullamcorper et lorem. Etiam in tellus vel tortor vestibulum faucibus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. In hac habitasse platea dictumst.</p>

				<p>Cras tincidunt gravida rhoncus. Praesent id risus tortor. Integer posuere tincidunt mattis. Sed eget consectetur dolor. Donec elit neque, ultrices eu placerat dapibus, scelerisque eu urna. Vivamus adipiscing odio quis urna consequat vitae malesuada lorem interdum. Integer quis dolor mauris.</p>

				<p>Suspendisse et aliquam tortor. Nam diam tellus, auctor sed pretium eu, elementum sit amet erat. Nam tempor lorem at augue pulvinar suscipit. Sed ut quam lorem, a auctor augue. Donec et orci sit amet odio tincidunt aliquet nec ac magna. Vestibulum sodales magna in dui lacinia volutpat. Maecenas congue libero at erat sodales fringilla. Vestibulum malesuada hendrerit diam, nec dictum dolor consequat porttitor. Sed eget volutpat ipsum. Fusce et arcu dignissim massa molestie pulvinar vitae vitae nulla. Aenean scelerisque viverra tincidunt.</p>
			</div>
		</div>
	</div>

</div><!-- main_content -->