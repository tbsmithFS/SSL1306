<?php

Class FormValidator {

    function validate($query) {

        $data['successful'] = true;


        //var_dump($query);
        // name
        if (!preg_match('/^[a-zA-Z ]+$/', $query['first_Name'])) {
            $data['successful'] = false;
            $data['first_Name']['has_error'] = true;
            $data['first_Name']['error_message'] = "Name must contain only letters and spaces.";
            //echo "test";
        }

         // name
        if (!preg_match('/^[a-zA-Z ]+$/', $query['last_Name'])) {
            $data['successful'] = false;
            $data['last_Name']['has_error'] = true;
            $data['last_Name']['error_message'] = "Name must contain only letters and spaces.";
            //echo "test";
        }

        // email
        if (!preg_match('/^\w+@\w+\.\w+$/', $query['email'])) {
            $data['successful'] = false;
            $data['email']['has_error'] = true;
            $data['email']['error_message'] = "Email address must look like user@example.com.";
        }

        // phone
        if(!preg_match('/^(\([2-9]|[2-9])(\d{2}|\d{2}\))(-|.|\s)?\d{3}(-|.|\s)?\d{4}$/', $query['phone'])) {
            $data['successful'] = false;
            $data['phone']['has_error'] = true;
            $data['phone']['error_message'] = "Must follow this format: 561-555-1234.";
         }
        
        // password
        if (strlen($query['password']) < 8) {
            $data['successful'] = false;
            $data['password']['has_error'] = true;
            $data['password']['error_message'] = "The password must be at least 8 characters long.";
        }

        // verify password
        if ($query['password'] != $query['confirmPassword']) {
            $data['successful'] = false;
            $data['confirmPassword']['has_error'] = true;
            $data['confirmPassword']['error_message'] = "Password did not match.";
        }  

        return $data;

    }   

}

?>
