<div id="main_content">

	<div class="light_bg">
		<div class="wrapper">
			<section>
				<h2>About</h2>

				<p>Joshua Jorgensen grew up in Windsor Ontario. He worked in IT services for a year and then went to school at Full Sail to obtain a degree in Web Design &amp; Development. He loves to design and develop applications for the web. He is a YouTube consultant for various TV shows. Jorgensen built his first application (<a href="https://itunes.apple.com/us/app/shark-mate!-shark-identification/id383806040?mt=8" title="Shark Mate">Shark Mate</a>) with Peter Kazazes, the founder of Sibyl Vision. Jorgensen is an avid angler. His fishing adventures have been featured in numerous media articles, including: CNN, CBS, Spiegel TV, Living Magazine, Sun Sentinel, and Global Angler.</p>
			</section>

			<img src="images/me_walking.jpg" alt="Joshua Jorgensen" />
		</div>
	</div>

	<div class="dark_bg">
		<div class="wrapper">

			<h2>Portfolio Work</h2>
			<p>Some of the companies that I have worked with:</p>

			<ul id="client_logos">
				<li><img src="/images/htdf.png" alt="how to Do Florida" /></li>
				<li><img src="/images/crawford.png" alt="Crawford Group" /></li>
			</ul>

		</div>
	</div>

</div><!-- main_content -->
