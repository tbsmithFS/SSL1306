<?php

require_once 'models/view.php';
include "models/DBConnector.php";

class User {
	function dispatch($query=''){
		if(empty($query['action'])){
			$action = 'home';
		}else {
			$action = $query['action'];
		}

		$v = new View();
		$v->printHeader();

		$data = array(
			'username' => 'Joe',
			'controller' => 'user'
		);

		if($action == 'home') {	
			$v->getView('user_home', $data);
		}
		else if($action == 'registration') {
			$data['bodyId']='registration'; //applies id to <body> for CSS
			$v->getView('header', $data);
			$v->getView('registration', $data);

		}
		else if ($action == 'perform_register') {
			$data['bodyId']='registration'; //applies id to <body> for CSS
			$v->getView('header', $data);

            $validation_data = $this->perform_register($_POST);

            if ($validation_data['successful'] == true) {
                $this->show_success_page();
            } else {
                $this->show_register_form($_POST, $validation_data);
            }            
        }
		else {
			$v->getView('user_home', $data);	
		}
		$v->getView('sidebar', $data);
		$v->getView('footer', $data);
	}

	function show_register_form($form_data=array(), $validation_data=array()) {
        require_once "views/registration.php";
    }

    function perform_register($form_data) {
        require_once "views/helpers/form_validator.php";
        $form_validator = new FormValidator();
        $validation_data = $form_validator->validate($form_data);

        $db = new DBConnector();

		$db->addUser(
			$_POST['first_Name'],
			$_POST['last_Name'],
			$_POST['email'],
			$_POST['phone'],
			$_POST['website'],
			$_POST['username'],
			$_POST['password']
		);
		// var_dump($db);

        return $validation_data;
    }

    function show_success_page() {
        require_once "views/register_success.php";
    }
}

?>