	<footer>
		<p>Copyright &copy; 2013 - Joshua Jorgensen</p>
	</footer>

	<!-- ******** Javascript ******** -->

	<script type="text/javascript" src="/js/gallery.js"></script>
	<script type="text/javascript" src="/js/ryu.js"></script>
	<!--<script type="text/javascript" src="/js/validate.js"></script>-->
	<script type="text/javascript" src="/js/accordion.js"></script>
	<script type="text/javascript" src="/js/blog.js"></script>
	<script type="text/javascript" src="/js/auto_complete.js"></script>

</body>
</html>