<?php

class DBConnector {

    public $db;

    function __construct() {
        $host = '127.0.0.1';
        $user = 'root';
        $pass = 'root';
        $port = '8889';
        $dbname = 'lab4_php';
        $this->db = new PDO("mysql:host=$host;port=$port;dbname=$dbname", $user, $pass);
    }

    public function addUser($firstname='', $lastname='', $email='', $phone='', $website='', $username='', $password='') {

        //This is a mySQL statement "INSERT INTO"
        $stmnt = $this->db->prepare("insert into users (firstname, lastname, email, phone, website, username, password) values (:firstname, :lastname, :email, :phone, :website, :username, :password)");

        $stmnt->execute(
            array(
                ':firstname' => $firstname,
                ':lastname' => $lastname,
                ':email' => $email,
                ':phone' => $phone,
                ':website' => $website,
                ':username' => $username,
                ':password' => $password
            )
        );
    }
}

?>
