<?php
	// header("Content-type:text/html");
	// print 1;

	header('Content-type: text/html');

	if(empty($_GET['controller'])) {
		$con = 'home';
	}else {
		$con = $_GET['controller'];
	}

	if($con == 'home') {
		include 'controllers/home.php';
		$controller = new Home();
		$controller->dispatch($_GET);
	}
	else if ($con == 'api') {
		include 'controllers/api.php';
		$controller = new Api();
		$controller->translate($_GET);
	}
	else {
		include 'controllers/home.php';
		$controller = new Home();
		$controller->dispatch($_GET);
	}

?>