<div id="main_content">

	<form method="post" action="/api/translate">
		<input type="text" name="words" />

		<select name="language">
			<option value="italian">Italian</option>
			<option value="french">French</option>
		</select>
		
		<input type="submit" value="Translate" name="translate" />
	</form>

</div><!-- main_content -->
