<?php

print 'API Class';

require_once 'models/view.php';
require_once "models/DBConnector.php";

class Api {
	function translate($query) {
		$v = new View();

		// print 'sdfsadafas';

		// $language = $query['language'];
		// $phrase = $query['words'];
		// $phrase = 'test'

		$url = 'http://glosbe.com/gapi/translate?from=$language&dest=eng&format=json&phrase=$phrase&pretty=true';

		$db = new DBConnector();
		$db->addTranslation(
			$_POST['language'],
			$_POST['words']
		);
		var_dump($_POST);
	}
}


?>