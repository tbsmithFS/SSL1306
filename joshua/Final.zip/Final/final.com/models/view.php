<?php

class View {
	function printHeader(){
		header('Content-type: text/html');
	}

	function getView($file='', $data=''){
		$fullPath = "/Users/BlacktipH/sites/final.com/views/$file.php";

		if(file_exists($fullPath)){
			include($fullPath);
		}
	}
}

?>