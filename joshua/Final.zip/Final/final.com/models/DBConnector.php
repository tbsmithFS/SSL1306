<?php

class DBConnector {

    public $db;

    //Constructor function
    public function __construct() {
        $host = '127.0.0.1';
        $user = 'root';
        $pass = 'root';
        $port = '8889';
        $dbName = 'phpFinal';
        $this->db = new PDO("mysql:host=$host;port=$port;dbname=$dbName", $user, $pass);
    }

    public function addTranslation($language, $words){
        $mySQL = $this->db->prepare("insert into translator (language, words) values(:language, :words)");

        $mySQL->execute (
            array(
            ':language' => $language,
            ':words' => $words
            )
        );
    }

}

?>
