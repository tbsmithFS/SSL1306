# ************************************************************
# Sequel Pro SQL dump
# Version 4096
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: 127.0.0.1 (MySQL 5.5.29)
# Database: phpFinal
# Generation Time: 2013-06-28 18:59:17 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table translator
# ------------------------------------------------------------

DROP TABLE IF EXISTS `translator`;

CREATE TABLE `translator` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `language` varchar(50) DEFAULT NULL,
  `words` varchar(100) DEFAULT NULL,
  `transDef` int(11) DEFAULT NULL,
  `defintion` int(11) DEFAULT NULL,
  `transWord` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `translator` WRITE;
/*!40000 ALTER TABLE `translator` DISABLE KEYS */;

INSERT INTO `translator` (`id`, `language`, `words`, `transDef`, `defintion`, `transWord`)
VALUES
	(1,'italian',NULL,NULL,NULL,NULL),
	(2,'italian',NULL,NULL,NULL,NULL),
	(3,'italian',NULL,NULL,NULL,NULL),
	(4,'italian',NULL,NULL,NULL,NULL),
	(5,'italian',NULL,NULL,NULL,NULL),
	(6,NULL,NULL,NULL,NULL,NULL),
	(7,'italian',NULL,NULL,NULL,NULL),
	(8,'italian',NULL,NULL,NULL,NULL),
	(9,'italian',NULL,NULL,NULL,NULL),
	(10,'italian',NULL,NULL,NULL,NULL),
	(11,'italian',NULL,NULL,NULL,NULL),
	(12,'italian',NULL,NULL,NULL,NULL),
	(13,'italian',NULL,NULL,NULL,NULL),
	(14,'french',NULL,NULL,NULL,NULL),
	(15,'italian',NULL,NULL,NULL,NULL),
	(16,NULL,NULL,NULL,NULL,NULL),
	(17,NULL,'afsdfad',NULL,NULL,NULL),
	(18,'italian','sdfasdfaf',NULL,NULL,NULL),
	(19,'italian','hello',NULL,NULL,NULL),
	(20,'italian','adfadsafas',NULL,NULL,NULL);

/*!40000 ALTER TABLE `translator` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
