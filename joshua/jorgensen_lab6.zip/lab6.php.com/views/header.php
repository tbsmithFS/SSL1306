<!DOCTYPE html>
<html lang="en">
<head>
	<!-- Mobile -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

	<title>Joshua Jorgensen | Home</title>
	<meta charset="utf-8"/>
	<meta name="description" content="" />
	<meta name="keywords" content="" />

	<!-- Google Web Fonts -->
	<link href='http://fonts.googleapis.com/css?family=Tauri|Roboto+Condensed:400,300' rel='stylesheet' type='text/css' />

	<!-- Favicon -->
	<link rel="shortcut icon" href="/images/favicon.ico" />

	<!-- CSS -->
	<link rel="stylesheet" href="/css/main.css" />
</head>

<body>
	<header id="header">
		<div class="wrapper">
			<a href="/" title="#"><h1>JSON Service Guide</h1></a>
		</div>
	</header>