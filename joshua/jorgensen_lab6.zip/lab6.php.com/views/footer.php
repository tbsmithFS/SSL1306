	<footer>
		<p>Copyright &copy; 2013 - Joshua Jorgensen</p>
	</footer>

</body>
</html>