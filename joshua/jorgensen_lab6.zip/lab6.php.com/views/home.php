<div id="main_content">

	<ul>
		<li>Call the URL:<a href="/api/getRandomUser">Get Random User</a> to get one random user.</li>
		<li>
			Call the URL:<a href="/api/lastname/searchTerm">Search Database</a> to search the database (maximum one parameter).
			<ul>
				<li>Make sure the searchField is a single word: firstname, lastname, phone, city, state, or zip</li>
				<li>Make sure the searchTerm is a single word.</li>
			</ul>
		</li>
	</ul>

	<h2>Read JSON from duckduckgo.com</h2>

	<label for="keyword">Keyword:</label>
	<input type="search" name="keyword" />

	<input type="submit" value="Submit" name="submit" />


</div><!-- main_content -->
