<?php

require_once 'models/view.php';

class Home {
	function dispatch($query=''){
		if(empty($query['action'])){
			$action = 'home';
		}else {
			$action = $query['action'];
		}

		$v = new View();
		$v->printHeader();

		$data = array(
			'username' => array('msg' => ''),
			'controller' => 'home'
		);

		if($action == 'home') {
			$v->getView('header', $data);
			$v->getView('home', $data);
		} 
		else {
			$v->getView('header', $data);
			$v->getView('home', $data);	
		}
		$v->getView('sidebar', $data);
		$v->getView('footer', $data);
	}
}

?>