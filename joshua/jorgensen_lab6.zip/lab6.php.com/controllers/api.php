<?php

// print 'API Class';

require_once 'models/view.php';
require_once "models/DBConnector.php";

echo();

class Api {
	$v = new View();

	/*if($action == 'getRandomUser', $data) {

	}*/
}

include_once "models/DBConnector.php";

$db = new DBConnector();

$result = $db->getRandomUser();
var_dump($result);




?>