<?php

class DBConnector {

    public $db;

    //Constructor function
    public function __construct() {
        $host = '127.0.0.1';
        $user = 'root';
        $pass = 'root';
        $port = '8889';
        $dbName = 'example1306';

        $this->db = new PDO("mysql:host=$host;port=$port;dbname=$dbName", $user, $pass);

    }

    public function getRandomUser() {
	    $SQL_Statement = $this->db->query("select * from users order by rand() limit 1");
	    return $SQL_Statement->fetchAll(PDO::FETCH_ASSOC);
	}

    public function getUserContent() {
        $SQL_Statement = $this->db->query("select lastname from users order by rand() limit 1");
        return $SQL_Statement->fetchAll(PDO::FETCH_ASSOC);
    }

}

?>
